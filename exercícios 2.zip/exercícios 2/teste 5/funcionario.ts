// ----------------------------------------------------------------------
// CLASSE ABSTRATA
// ----------------------------------------------------------------------

/**
 * Classe Abstrata base para todos os funcionários.
 * Garante que o método calcularBonus() seja implementado em todas as subclasses.
 */
abstract class Funcionario {
    // Atributos encapsulados usando 'protected' para permitir acesso em subclasses
    protected nome: string;
    protected salario: number;

    constructor(nome: string, salario: number) {
        this.nome = nome;
        this.salario = salario;
    }

    /**
     * Método abstrato. Deve ser implementado por Gerente e Operario.
     * @returns O valor do bônus (number).
     */
    public abstract calcularBonus(): number;

    /**
     * Getter para acessar o salário de forma controlada (encapsulamento).
     */
    public getSalario(): number {
        return this.salario;
    }

    /**
     * Getter para acessar o nome.
     */
    public getNome(): string {
        return this.nome;
    }
}

// ----------------------------------------------------------------------
// SUBCLASSES CONCRETAS
// ----------------------------------------------------------------------

/**
 * Subclasse Gerente. Bônus de 10% do salário.
 */
class Gerente extends Funcionario {
    // Implementação obrigatória do método abstrato
    public calcularBonus(): number {
        // Bônus de 10%
        return this.salario * 0.10;
    }
}

/**
 * Subclasse Operario. Bônus de 5% do salário.
 */
class Operario extends Funcionario {
    // Implementação obrigatória do método abstrato
    public calcularBonus(): number {
        // Bônus de 5%
        return this.salario * 0.05;
    }
}

// ----------------------------------------------------------------------
// FUNÇÃO DE PROCESSAMENTO (POLIMORFISMO)
// ----------------------------------------------------------------------

/**
 * Função que calcula o salário final (Salário + Bônus) para todos os funcionários
 * em um array, usando o método específico de cada subclasse.
 * @param funcionarios Array contendo subclasses de Funcionario.
 */
function calcularSalarioComBonus(funcionarios: Funcionario[]): void {
    console.log("\n--- CÁLCULO DE SALÁRIOS COM BÔNUS ---");

    funcionarios.forEach(f => {
        const bonus = f.calcularBonus();
        const salarioFinal = f.getSalario() + bonus;

        console.log(`
        Nome: ${f.getNome()} (${f.constructor.name})
        Salário Base: R$ ${f.getSalario().toFixed(2)}
        Bônus Calculado: R$ ${bonus.toFixed(2)}
        Salário Final: R$ ${salarioFinal.toFixed(2)}
        `);
    });
    console.log("---------------------------------------");
}

// --- Exemplo de Uso ---

// 1. Criação de instâncias
const joaoGerente = new Gerente("João Silva", 5000.00);
const mariaOperaria = new Operario("Maria Santos", 2000.00);
const pedroGerente = new Gerente("Pedro Alvares", 8500.00);

// 2. Criação do array de Funcionario (Polimorfismo em ação)
const equipe: Funcionario[] = [
    joaoGerente,
    mariaOperaria,
    pedroGerente
];

// 3. Chamada da função de processamento
calcularSalarioComBonus(equipe);