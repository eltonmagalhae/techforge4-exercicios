/**
 * Classe base Animal.
 * Contém o atributo privado 'energia' e o método 'comer'.
 */
class Animal {
    // Atributo privado, acessível apenas dentro da classe e subclasses (protected)
    protected energia: number;

    constructor(energiaInicial: number = 50) {
        this.energia = energiaInicial;
    }

    /**
     * Método padrão para aumentar a energia do animal.
     * As subclasses Leao e Passaro irão sobrescrevê-lo.
     */
    public comer(quantidade: number): void {
        this.energia += quantidade;
        console.log(`[Animal] Energia aumentada em ${quantidade}.`);
    }

    /**
     * Exibe o nível de energia atual do animal.
     */
    public statusEnergia(): void {
        const nomeAnimal = this.constructor.name;
        console.log(`- Status de ${nomeAnimal}: Energia atual é ${this.energia}%.`);
    }
}

// ----------------------------------------------------------------------

/**
 * Subclasse Leão. Sobrescreve comer() com lógica de caça.
 */
class Leao extends Animal {
    constructor(energiaInicial: number = 70) {
        super(energiaInicial);
    }

    /**
     * Sobrescreve comer() para simular CAÇAR:
     * 1. Gasta 10 de energia para caçar.
     * 2. Recupera a quantidade de energia especificada.
     */
    public comer(quantidade: number): void {
        const custoCaca = 10;
        this.energia -= custoCaca; // Gasta energia
        console.log(`[Leão] Caçando... Gasta ${custoCaca}% de energia.`);

        super.comer(quantidade); // Recupera energia usando o método base ou implementa a recuperação
        console.log(`[Leão] Caçada bem-sucedida!`);
    }
}

// ----------------------------------------------------------------------

/**
 * Subclasse Pássaro. Sobrescreve comer() para alimentação simples.
 */
class Passaro extends Animal {
    constructor(energiaInicial: number = 30) {
        super(energiaInicial);
    }

    /**
     * Sobrescreve comer() para simular ALIMENTAÇÃO SIMPLES.
     */
    public comer(quantidade: number): void {
        super.comer(quantidade); // Simplesmente aumenta a energia
        console.log(`[Pássaro] Alimentado com sementes.`);
    }
}

// ----------------------------------------------------------------------
// FUNÇÃO DE PROCESSAMENTO (POLIMORFISMO)
// ----------------------------------------------------------------------

/**
 * Função que processa a alimentação de diferentes animais.
 * @param animais Array de objetos Animal.
 * @param quantidade Quantidade de energia a ser consumida/ganha.
 */
function alimentarAnimais(animais: Animal[], quantidade: number): void {
    console.log("\n--- INICIANDO ALIMENTAÇÃO ---");
    animais.forEach(animal => {
        animal.statusEnergia();
        animal.comer(quantidade);
        animal.statusEnergia();
        console.log("-----------------------------");
    });
}

// --- Exemplo de Uso ---

// 1. Criação de instâncias
const simba = new Leao();
const piu = new Passaro();

// 2. Criação do array de Animal
const fauna: Animal[] = [simba, piu];

// 3. Chamada da função polimórfica (o método 'comer' se comporta de forma diferente)
alimentarAnimais(fauna, 30);