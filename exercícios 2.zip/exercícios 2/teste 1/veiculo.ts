/**
 * Classe base (Superclasse) que representa um Veículo genérico.
 */
class Veiculo {
    /**
     * Método padrão para mover um veículo.
     */
    public mover(): void {
        console.log("O veículo está se movendo.");
    }
}

// ----------------------------------------------------------------------

/**
 * Subclasse que representa um Carro.
 * Ela herda (extends) de Veiculo.
 */
class Carro extends Veiculo {
    // Sobrescreve (override) o método mover() da superclasse
    public mover(): void {
        console.log("O carro está dirigindo.");
    }
}

// ----------------------------------------------------------------------

/**
 * Subclasse que representa uma Bicicleta.
 * Ela herda (extends) de Veiculo.
 */
class Bicicleta extends Veiculo {
    // Sobrescreve (override) o método mover() da superclasse
    public mover(): void {
        console.log("A bicicleta está pedalando.");
    }
}

// --- Teste e Instanciação ---

console.log("\n--- Demonstração de Herança e Polimorfismo ---");

// 1. Instanciar um objeto da classe base (opcional)
const veiculoGenerico = new Veiculo();
veiculoGenerico.mover(); // Saída: O veículo está se movendo.

// 2. Instanciar a subclasse Carro
const meuCarro = new Carro();
// Chama o método SOBRESCRITO da classe Carro
meuCarro.mover(); // Saída: O carro está dirigindo.

// 3. Instanciar a subclasse Bicicleta
const minhaBicicleta = new Bicicleta();
// Chama o método SOBRESCRITO da classe Bicicleta
minhaBicicleta.mover(); // Saída: A bicicleta está pedalando.