// ----------------------------------------------------------------------
// CLASSE ABSTRATA
// ----------------------------------------------------------------------

/**
 * Classe Abstrata base para todas as figuras geométricas.
 * Classes abstratas não podem ser instanciadas diretamente e
 * devem ter métodos abstratos implementados pelas subclasses.
 */
abstract class FiguraGeometrica {
    /**
     * Método abstrato. Deve ser implementado por qualquer subclasse.
     * @returns A área calculada da figura.
     */
    public abstract calcularArea(): number;

    /**
     * Método concreto (opcional) para exibição.
     */
    public exibirDetalhes(): void {
        const nomeClasse = this.constructor.name;
        const area = this.calcularArea().toFixed(2);
        console.log(`Área da ${nomeClasse}: ${area}`);
    }
}

// ----------------------------------------------------------------------
// SUBCLASSES CONCRETAS
// ----------------------------------------------------------------------

/**
 * Subclasse Círculo. Implementa o cálculo de área (π * raio²).
 */
class Circulo extends FiguraGeometrica {
    private raio: number;

    constructor(raio: number) {
        super();
        this.raio = raio;
    }

    // Implementação obrigatória do método abstrato
    public calcularArea(): number {
        return Math.PI * this.raio * this.raio;
    }
}

/**
 * Subclasse Quadrado. Implementa o cálculo de área (lado * lado).
 */
class Quadrado extends FiguraGeometrica {
    private lado: number;

    constructor(lado: number) {
        super();
        this.lado = lado;
    }

    // Implementação obrigatória do método abstrato
    public calcularArea(): number {
        return this.lado * this.lado;
    }
}

/**
 * Subclasse Triangulo. Implementa o cálculo de área (base * altura / 2).
 */
class Triangulo extends FiguraGeometrica {
    private base: number;
    private altura: number;

    constructor(base: number, altura: number) {
        super();
        this.base = base;
        this.altura = altura;
    }

    // Implementação obrigatória do método abstrato
    public calcularArea(): number {
        return (this.base * this.altura) / 2;
    }
}

// ----------------------------------------------------------------------
// FUNÇÃO DE PROCESSAMENTO (POLIMORFISMO)
// ----------------------------------------------------------------------

/**
 * Função que aceita um array de FiguraGeometrica e chama o método calcularArea()
 * de cada objeto, demonstrando o polimorfismo.
 * @param figuras Array contendo qualquer subclasse de FiguraGeometrica.
 */
function imprimirAreas(figuras: FiguraGeometrica[]): void {
    console.log("\n--- CALCULANDO ÁREAS ---");
    figuras.forEach(figura => {
        // O TS sabe que o método calcularArea() existe e chama a
        // implementação específica da subclasse (Círculo, Quadrado ou Triangulo).
        figura.exibirDetalhes();
    });
    console.log("--------------------------");
}

// --- Exemplo de Uso ---

// 1. Criação de instâncias das diferentes subclasses
const meuCirculo = new Circulo(5); // Raio = 5
const meuQuadrado = new Quadrado(4); // Lado = 4
const meuTriangulo = new Triangulo(6, 8); // Base = 6, Altura = 8

// 2. Criação do array de FiguraGeometrica
const listaDeFiguras: FiguraGeometrica[] = [
    meuCirculo,
    meuQuadrado,
    meuTriangulo,
    new Circulo(2.5) // Adicionando mais um Círculo diretamente
];

// 3. Chamada da função de processamento
imprimirAreas(listaDeFiguras);