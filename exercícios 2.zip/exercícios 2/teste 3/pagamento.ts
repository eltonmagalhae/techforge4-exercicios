/**
 * Classe base (Superclasse) abstrata para todos os tipos de pagamento.
 * Usar 'abstract' garante que o método processar() deve ser implementado
 * pelas subclasses e que a classe base não pode ser instanciada.
 */
abstract class Pagamento {
    protected valor: number;

    constructor(valor: number) {
        this.valor = valor;
    }

    /**
     * Método abstrato. Deve ser implementado por todas as subclasses.
     * @returns Uma string indicando o resultado do processamento.
     */
    public abstract processar(): string;
}

// ----------------------------------------------------------------------

/**
 * Subclasse para processamento de pagamento via Cartão.
 */
class PagamentoCartao extends Pagamento {
    private numeroCartao: string;

    constructor(valor: number, numeroCartao: string) {
        super(valor);
        this.numeroCartao = numeroCartao;
    }

    private validarCartao(): boolean {
        // Simplesmente verifica se o número do cartão tem 16 dígitos.
        // Em um sistema real, haveria validação de bandeira, CVV, etc.
        return this.numeroCartao.length === 16 && !isNaN(Number(this.numeroCartao));
    }

    /**
     * Sobrescreve o método processar() para lógica de Cartão.
     */
    public processar(): string {
        if (this.validarCartao()) {
            return `[Cartão - SUCESSO] Processando R$ ${this.valor.toFixed(2)}. Cartão validado e transação aprovada.`;
        } else {
            return `[Cartão - ERRO] Falha ao validar o número do cartão (${this.numeroCartao}). Pagamento recusado.`;
        }
    }
}

// ----------------------------------------------------------------------

/**
 * Subclasse para processamento de pagamento via Boleto.
 */
class PagamentoBoleto extends Pagamento {

    constructor(valor: number) {
        super(valor);
    }

    private gerarCodigoBoleto(): string {
        // Gera um código de barras de boleto simulado
        const codigo = Math.random().toString().substring(2, 12);
        return `34191.${codigo}.00000.123456.78901.234567.890`;
    }

    /**
     * Sobrescreve o método processar() para lógica de Boleto.
     */
    public processar(): string {
        const codigoBoleto = this.gerarCodigoBoleto();
        return `[Boleto - SUCESSO] Boleto de R$ ${this.valor.toFixed(2)} gerado. Código de barras: ${codigoBoleto}`;
    }
}

// ----------------------------------------------------------------------
// FUNÇÃO DE PROCESSAMENTO POLIMÓRFICO
// ----------------------------------------------------------------------

/**
 * Função que aceita um array de objetos Pagamento e processa cada um.
 * O TypeScript/JavaScript chama automaticamente o método processar()
 * específico da subclasse (Cartao ou Boleto).
 * @param pagamentos Array contendo diferentes tipos de Pagamento.
 */
function processarPagamentos(pagamentos: Pagamento[]): void {
    console.log("\n--- INICIANDO PROCESSAMENTO DE PAGAMENTOS ---");
    pagamentos.forEach(pagamento => {
        const resultado = pagamento.processar();
        console.log(resultado);
    });
    console.log("--- FIM DO PROCESSAMENTO ---");
}

// --- Exemplo de Uso ---

// 1. Criação de instâncias dos diferentes tipos de pagamento
const pgtCartaoSucesso = new PagamentoCartao(150.50, "1234567890123456"); // Válido (16 dígitos)
const pgtCartaoErro = new PagamentoCartao(45.00, "12345"); // Inválido
const pgtBoleto = new PagamentoBoleto(99.90);
const pgtBoletoMaior = new PagamentoBoleto(1500.00);


// 2. Criação do array de Pagamento
const transacoes: Pagamento[] = [
    pgtCartaoSucesso,
    pgtCartaoErro,
    pgtBoleto,
    pgtBoletoMaior
];

// 3. Chamada da função de processamento
processarPagamentos(transacoes);