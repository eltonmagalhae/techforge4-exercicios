// Conteúdo do arquivo produto.ts

/**
 * Classe que representa um Produto em estoque.
 */
class Produto {
    private nome: string;
    private preco: number;
    private quantidade: number;

    /**
     * Construtor da classe Produto.
     */
    constructor(nome: string, preco: number, quantidade: number) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        console.log(`Produto "${this.nome}" adicionado ao estoque.`);
    }

    // --- Método de Cálculo ---

    /**
     * Calcula o valor monetário total de todas as unidades deste produto em estoque.
     */
    public calcularValorTotalEmEstoque(): number {
        const valorTotal = this.preco * this.quantidade;
        return valorTotal;
    }

    // --- Método de Informação ---

    /**
     * Exibe o nome, preço e quantidade do produto, além do valor total em estoque.
     */
    public exibirDetalhes(): void {
        const valorTotal = this.calcularValorTotalEmEstoque();
        console.log("-----------------------------------------");
        console.log(`Nome: ${this.nome}`);
        console.log(`Preço Unitário: R$ ${this.preco.toFixed(2)}`);
        console.log(`Quantidade em Estoque: ${this.quantidade} unidades`);
        console.log(`VALOR TOTAL EM ESTOQUE: R$ ${valorTotal.toFixed(2)}`);
        console.log("-----------------------------------------");
    }
}

// --- Exemplo de Uso ---
console.log("\n--- Teste da Classe Produto ---");
const caneta = new Produto("Caneta Esferográfica", 2.50, 100);
const valorTotalCanetas = caneta.calcularValorTotalEmEstoque();
console.log(`O valor total em estoque de "${caneta}" é R$ ${valorTotalCanetas.toFixed(2)}.`);

const caderno = new Produto("Caderno Universitário", 15.99, 50);
caderno.exibirDetalhes();