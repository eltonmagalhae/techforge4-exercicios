/**
 * Classe que representa uma Agenda e gerencia uma lista de compromissos.
 */
class Agenda {
    // Atributo privado que armazena os compromissos como um array de strings.
    private compromissos: string[];

    /**
     * Construtor da classe Agenda.
     * Inicializa o array de compromissos como vazio.
     */
    constructor() {
        this.compromissos = [];
        console.log("Agenda criada com sucesso.");
    }

    // --- Métodos de Ação ---

    /**
     * Adiciona um novo compromisso à agenda.
     * @param descricao A descrição do compromisso a ser adicionado.
     */
    public adicionarCompromisso(descricao: string): void {
        this.compromissos.push(descricao);
        console.log(`[OK] Compromisso adicionado: "${descricao}"`);
    }

    /**
     * Lista todos os compromissos registrados na agenda.
     */
    public listarCompromissos(): void {
        console.log("\n--- COMPROMISSOS NA AGENDA ---");
        
        if (this.compromissos.length === 0) {
            console.log("Nenhum compromisso agendado.");
            return;
        }

        this.compromissos.forEach((compromisso, indice) => {
            console.log(`${indice + 1}. ${compromisso}`);
        });
        console.log("------------------------------");
    }
}

// --- Exemplo de Uso ---

console.log("\n--- Teste da Classe Agenda ---");

// 1. Criação da agenda
const minhaAgenda = new Agenda();

// 2. Adição de compromissos
minhaAgenda.adicionarCompromisso("Reunião de equipe às 10h");
minhaAgenda.adicionarCompromisso("Consulta médica às 14h30");
minhaAgenda.adicionarCompromisso("Fazer supermercado após o trabalho");

// 3. Listagem dos compromissos
minhaAgenda.listarCompromissos();