/**
 * Classe que representa um livro.
 */
class Livro {
    private titulo: string;
    private autor: string;
    private paginas: number;
    private lido: boolean;

    constructor(titulo: string, autor: string, paginas: number, lido: boolean = false) {
        this.titulo = titulo;
        this.autor = autor;
        this.paginas = paginas;
        this.lido = lido;
        console.log(`Livro "${this.titulo}" criado.`);
    }

    public marcarComoLido(status: boolean): void {
        this.lido = status;
        if (this.lido) {
            console.log(`O livro "${this.titulo}" foi marcado como LIDO.`);
        } else {
            console.log(`O livro "${this.titulo}" foi marcado como NÃO LIDO.`);
        }
    }

    public getStatusLeitura(): string {
        const status = this.lido ? "Lido" : "Não Lido";
        return `"${this.titulo}" | Autor: ${this.autor} | Páginas: ${this.paginas} | Status: ${status}`;
    }
}

// --- Exemplo de Uso ---
console.log("\n--- Teste da Classe Livro ---");
const livro1 = new Livro("O Hobbit", "J.R.R. Tolkien", 310);
console.log(livro1.getStatusLeitura());
livro1.marcarComoLido(true);
console.log(livro1.getStatusLeitura());
const livro2 = new Livro("1984", "George Orwell", 328, true);
console.log(livro2.getStatusLeitura());
livro2.marcarComoLido(false);
console.log(livro2.getStatusLeitura());