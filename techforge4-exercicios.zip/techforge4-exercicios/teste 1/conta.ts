// ContaBancaria.ts (Sintaxe Simplificada)

class ContaBancaria {
    /**
     * Declara, define o modificador de acesso E inicializa as propriedades
     * em uma única linha dentro do construtor.
     */
    constructor(
        private titular: string, // Propriedade 'titular' é criada e inicializada
        private saldo: number = 0  // Propriedade 'saldo' é criada e inicializada (padrão 0)
    ) {
        console.log(`Conta de ${this.titular} criada.`);
    }

    // ... (Os métodos 'depositar' e 'sacar' seriam os mesmos)
}