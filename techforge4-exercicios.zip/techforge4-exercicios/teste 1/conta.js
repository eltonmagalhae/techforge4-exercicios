var ContaBancaria = /** @class */ (function () {
    /**
     * Construtor da classe.
     * As propriedades são inicializadas aqui.
     * @param titular O nome do titular da conta.
     * @param saldoInicial O saldo inicial da conta (padrão 0).
     */
    function ContaBancaria(titular, saldoInicial) {
        if (saldoInicial === void 0) { saldoInicial = 0; }
        // Inicializa as propriedades, resolvendo o erro de compilação
        this.titular = titular;
        this.saldo = saldoInicial;
    }
    /**
     * Adiciona um valor ao saldo.
     * @param valor O valor a ser depositado.
     */
    ContaBancaria.prototype.depositar = function (valor) {
        if (valor > 0) {
            this.saldo += valor;
            console.log("Dep\u00F3sito de R$ ".concat(valor.toFixed(2), " realizado. Novo saldo: R$ ").concat(this.saldo.toFixed(2), "."));
        }
    };
    /**
     * Retira um valor do saldo, se houver fundos suficientes.
     * @param valor O valor a ser sacado.
     */
    ContaBancaria.prototype.sacar = function (valor) {
        if (valor > 0 && this.saldo >= valor) {
            this.saldo -= valor;
            console.log("Saque de R$ ".concat(valor.toFixed(2), " realizado. Novo saldo: R$ ").concat(this.saldo.toFixed(2), "."));
        }
        else if (this.saldo < valor) {
            console.error("Erro: Saldo insuficiente.");
        }
    };
    return ContaBancaria;
}());
// Exemplo de uso (Para verificar se tudo está funcionando)
var minhaConta = new ContaBancaria("João Silva", 100);
minhaConta.depositar(50);
minhaConta.sacar(20);
minhaConta.sacar(500); // Erro de saldo
