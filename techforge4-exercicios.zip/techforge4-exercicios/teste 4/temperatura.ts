/**
 * Classe que representa uma temperatura em graus Celsius e fornece
 * métodos para converter para Fahrenheit e Kelvin.
 */
class Temperatura {
    // Atributo privado que armazena o valor em Celsius
    private valorCelsius: number;

    /**
     * Construtor da classe Temperatura.
     * @param valorCelsius A temperatura inicial em graus Celsius.
     */
    constructor(valorCelsius: number) {
        this.valorCelsius = valorCelsius;
        console.log(`Temperatura inicial definida: ${this.valorCelsius}°C`);
    }

    // --- Métodos de Conversão ---

    /**
     * Converte o valor de Celsius para Fahrenheit.
     * Fórmula: F = C * 9/5 + 32
     * @returns O valor da temperatura em Fahrenheit (number).
     */
    public paraFahrenheit(): number {
        const fahrenheit = (this.valorCelsius * 9/5) + 32;
        return fahrenheit;
    }

    /**
     * Converte o valor de Celsius para Kelvin.
     * Fórmula: K = C + 273.15
     * @returns O valor da temperatura em Kelvin (number).
     */
    public paraKelvin(): number {
        const kelvin = this.valorCelsius + 273.15;
        return kelvin;
    }

    // --- Método de Exibição ---

    /**
     * Exibe o valor da temperatura em todas as três escalas.
     */
    public exibirTemperaturas(): void {
        const f = this.paraFahrenheit().toFixed(2);
        const k = this.paraKelvin().toFixed(2);
        const c = this.valorCelsius.toFixed(2);
        
        console.log("-----------------------------------------");
        console.log(`Celsius (°C):    ${c}`);
        console.log(`Fahrenheit (°F): ${f}`);
        console.log(`Kelvin (K):      ${k}`);
        console.log("-----------------------------------------");
    }
}

// --- Exemplo de Uso ---

console.log("\n--- Teste da Classe Temperatura ---");

// Criação de uma instância com 25°C
const temp = new Temperatura(25);

// Exibe todas as conversões
temp.exibirTemperaturas();

// Exemplo do ponto de congelamento da água (0°C)
const tempCongelamento = new Temperatura(0);
tempCongelamento.exibirTemperaturas();